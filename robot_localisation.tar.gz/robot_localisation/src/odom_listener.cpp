#include "ros/ros.h"
#include "nav_msgs/Odometry.h"
#include "mavros_msgs/WheelOdomStamped.h"
#include <tf/transform_broadcaster.h>
#include <Eigen/Dense>
#include "robotpose.h"
#include <robotmodel.h>
#include <ekf.h>
#include <localisation.h>

//using namespace std;
using namespace Eigen;
 class Controller {
 private:
     ros::NodeHandle* n;
     ros::Subscriber sub;
     ros::Publisher pub;
     EKF localisation;
     nav_msgs::Odometry odom; //ovo cu da publishujem
     geometry_msgs::Quaternion odom_quat; //dodao
     geometry_msgs::TransformStamped odom_trans; //dodao
     tf::TransformBroadcaster odom_broadcaster; //dodao
     ros::Time currentTime;
     ros::Time lastTime; // mora bit sve ovo gore

     double DistancePerCount;
     double v_left;
     double v_right;
     double tick_x;
     double tick_y;
     double v = 0;
     double omega = 0;
     const double omegamax = 0.407;
     Vector2d currentVelocity;
     const double R = 0.2;
     const double b = 0.4;
     const double k = 0.0001853; //function between velocity and encoder
     const double T = 0.1;
     const double pi = 3.14159265;
 public:
     Controller(ros::NodeHandle* n_) : n(n_) {
         sub = n->subscribe("/mavros/wheel_odometry/rpm", 1000, &Controller::Callback, this);
         pub = n->advertise<nav_msgs::Odometry>("/mavros/odom", 1000);
         localisation = EKF(R, b, T);
         DistancePerCount  = (2 * pi * R/2) / 38; //2*pi*(R/2) / ppr
     }

     void Callback(const mavros_msgs::WheelOdomStamped::ConstPtr& msg)
     {
         currentVelocity = EstimateVelocity(msg->data);
         Publisher();
     }
     Vector2d EstimateVelocity(std::vector<float> vector) {
         tick_x = vector[0]; tick_y = vector[1]; //LEFT AND RIGHT ENCODER

         currentTime = ros::Time::now();
         v_left = k*tick_x;
         v_right = k*tick_y;

         v = (v_left + v_right)/2;
         omega = (v_left - v_right)/b;                   // max omega=0.407

         if(omega > omegamax ) omega = omegamax;
         else if(omega < -omegamax) omega = -omegamax;

         return Vector2d(v, omega);
     }

     void Publisher() {
         ros::Rate loop_rate(10); //0.1s
         lastTime = ros::Time::now();

         odom.header.frame_id = "odom";
         odom_trans.header.frame_id = "odom";
         odom_trans.child_frame_id = "base_link";
         while (ros::ok())
         {
          currentTime = ros::Time::now();

          localisation.predict(currentVelocity); ////EKF WORKING!!!
          localisation.correct();

          //since all odometry is 6DOF we'll need a quaternion created from yaw
          odom_quat = tf::createQuaternionMsgFromYaw(localisation.EstimatedPose().getTheta());
          odom.header.stamp = currentTime;
          odom_trans.header.stamp = currentTime;
          //position
          odom.pose.pose.position.x = localisation.EstimatedPose().getX();
          odom.pose.pose.position.y = localisation.EstimatedPose().getY();
          odom.pose.pose.position.z = 0.0;
          odom.pose.pose.orientation = odom_quat;

          ////DODAO SVE ZA ODOM_TRANS
          odom_trans.transform.translation.x = localisation.EstimatedPose().getX();
          odom_trans.transform.translation.y = localisation.EstimatedPose().getY();
          odom_trans.transform.translation.z = 0.0;
          odom_trans.transform.rotation = odom_quat;

          //send the transform
          odom_broadcaster.sendTransform(odom_trans);

          //OVO NE MORAM ZAVRSIT, NEK STOJI OVAKO.
          //Matrix3d Q = localisation.getQ();
          boost::array<double, 36> covar = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; //didnt work on this
          odom.pose.covariance =  covar;

          //set the velocity
          odom.child_frame_id = "base_link";
          odom.twist.twist.linear.x = currentVelocity[0]*cos(localisation.EstimatedPose().getTheta());
          odom.twist.twist.linear.y = currentVelocity[0]*sin(localisation.EstimatedPose().getTheta());
          odom.twist.twist.angular.z = currentVelocity[1];

          odom.twist.covariance = covar;

          pub.publish(odom); //PUBLISH FINAL

          ros::spinOnce();
          loop_rate.sleep();
        }
     }

 };

int main(int argc, char **argv)
{
  ros::init(argc, argv, "odom_listener");
  ros::NodeHandle n;
  Controller ctrl(&n); //publisher and subscriber

  ros::spin();

  return 0;
}

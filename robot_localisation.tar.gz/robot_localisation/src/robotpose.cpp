#include "robotpose.h"
using namespace std;

RobotPose::RobotPose(): x(0), y(0), theta(0){}
RobotPose::RobotPose(double a, double b, double c): x(a), y(b), theta(c) {}
void RobotPose::setX(double a) {x = a;}
void RobotPose::setY(double a) {y = a;}
void RobotPose::setTheta(double a) {theta = a;}
double RobotPose::getX() {return x;}
double RobotPose::getY() {return y;}
double RobotPose::getTheta() {return theta;}
void RobotPose::IspisiPoziciju() {
    cout << "x = " << x << endl;
    cout << "y = " << y << endl;
    cout << "theta = " << theta << endl;
}


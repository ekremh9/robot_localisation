#include "localisation.h"

using namespace Eigen;

Localisation::Localisation()  { robot = RobotModel();}
Localisation::Localisation(RobotModel r):robot(r) {}




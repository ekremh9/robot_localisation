#include "robotmodel.h"

using namespace Eigen;

RobotModel::RobotModel(){}
RobotModel::RobotModel(double r1, double B, double T1): r(r1), b(B), T(T1) {
    position.setX(0); position.setY(0); position.setTheta(0);
}
RobotModel::RobotModel(double r1, double B,double T1, RobotPose startPose): r(r1), b(B), T(T1) {
    position = startPose;
}
RobotPose RobotModel::getPose(){ return position; }
double RobotModel::getTs() {return T;}
double RobotModel::getR() {return r;}
double RobotModel::getB() {return b;}
void RobotModel::setR(double a) {r = a;}
void RobotModel::setB(double a) {b = a;}
void RobotModel::setT(double T1){T = T1;}
void RobotModel::setPose(Vector3d vektor) {
    position.setX(vektor[0]);
    position.setY(vektor[1]);
    position.setTheta(vektor[2]);
}
//diretkna kinematika
void RobotModel::iterate(Vector2d u)  {
    position.setTheta( position.getTheta() + u[1]*T );
    double D = u[0]*T;
    position.setX( position.getX() + D*cos(position.getTheta()));
    position.setY( position.getY() + D*sin(position.getTheta()));
}


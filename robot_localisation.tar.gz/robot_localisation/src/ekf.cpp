#include "ekf.h"

using namespace Eigen;

EKF::EKF(){/*robot = RobotModel(); */ }
EKF::EKF(RobotModel r) {robot = r;}
EKF::EKF(double r1, double B, double T1): Localisation(RobotModel(r1,B,T1)) {}

void EKF::predict(Vector2d u){
    if(u == Vector2d(0,0)) {sig_d = 0; return;} //no moving
    robot.iterate(u);                       //DIRECT KINEMATICS
    RobotPose x_1 = robot.getPose();        // -//-
    double D = u[0]*robot.getTs();
    sig_th = Noise(0.0031);
    sig_d = Noise(0.0052);

    x = x_1.getX() + sig_d;
    y = x_1.getY() + sig_d;
    theta = x_1.getTheta() + sig_th;

    z = sqrt(pow(x - x_1.getX(),2) + pow(y - x_1.getY(),2)) + sig_d;
    yz = z - sqrt(pow(x - x_1.getX(),2) + pow(y - x_1.getY(),2));

    F << 1, 0, -D*sin(x_1.getTheta()),
         0, 1, D*cos(x_1.getTheta()),
         0, 0, 1;

    W << -D*sin(x_1.getTheta()), cos(x_1.getTheta()), 0,
         D*cos(x_1.getTheta()), sin(x_1.getTheta()), 0,
         0, 0, 1;

    Q << u[0]*robot.getTs()*sig_th*sig_th, 0, 0,
            0, sig_d*sig_d, 0,
            0, 0, 0;

    P = F*P*F.transpose() + W*Q*W.transpose();
    //end of predict
}
void EKF::correct(){ // correcting
    if(sig_d == 0) return; //no moving
    RowVector3d state ; state << x, y, theta ;
    S = H(state)*P*H(state).transpose();

    K = P*H(state).transpose()/S;

    P = (MatrixXd::Identity(3,3) - K*H(state))*P;

    Vector3d pomocni = Vector3d(x,y,theta) + K*yz;
    robot.setPose(pomocni);
}
RowVector3d EKF::H (RowVector3d state) {
    RobotPose x_p = robot.getPose();
    RowVector3d pose ; pose << x_p.getX(), x_p.getY() , theta ;

    return (state - pose)/sqrt(pow((pose[0] - state[0]),2) + pow((pose[1] - state[1]),2));
}
Matrix3d EKF::getQ() {
    return Q;
}
double EKF::Noise(double x) {
    std::default_random_engine generator; //no need for random library
    std::normal_distribution<double> distribution(0,x);
    return distribution(generator);
}
RobotPose EKF::EstimatedPose() const {
    return RobotPose(x,y,theta);
}

#ifndef EKF_H
#define EKF_H

#include <Eigen/Dense>
#include <localisation.h>
#include <robotmodel.h>
#include <robotpose.h>

//class Localisation;

using namespace Eigen;

class EKF : public Localisation  
{
private:
    double sig_d;
    double sig_th;
    Matrix3d P = MatrixXd::Identity(3,3);
    Matrix3d F = MatrixXd::Zero(3,3);
    Matrix3d R = MatrixXd::Identity(3,3); 
    Matrix3d Q = MatrixXd::Identity(3,3); 
    Matrix3d W = MatrixXd::Zero(3,3);
    double S = 0; 
    Vector3d K = MatrixXd::Zero(3,1);
    double z;
    double yz;
public:
    EKF();
    EKF(RobotModel r);
    EKF(double r1, double B, double T1);
    void predict(Vector2d u);
    void correct();
    RowVector3d H(RowVector3d x_p);
    Matrix3d getQ();
    double Noise(double x);
    RobotPose EstimatedPose() const;
};

#endif // EKF_H

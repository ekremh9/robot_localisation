#ifndef ROBOTPOSE_H
#define ROBOTPOSE_H

#include <iostream>

class RobotPose
{
private:
    double x;
    double y;
    double theta;
public:
    RobotPose();
    RobotPose(double a, double b, double c);
    void setX(double a);
    void setY(double a);
    void setTheta(double a);
    double getX();
    double getY();
    double getTheta();
    void IspisiPoziciju();
};




#endif // ROBOTPOSE_H

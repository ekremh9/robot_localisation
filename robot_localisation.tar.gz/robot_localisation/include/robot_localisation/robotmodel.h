#ifndef ROBOTMODEL_H
#define ROBOTMODEL_H

#include <Eigen/Dense>
#include <robotpose.h>

using namespace Eigen;

class RobotModel
{
private:
    RobotPose position;
    double r;
    double b;
    double T;
public:
    RobotModel();
    RobotModel(double r1, double B, double T1);
    RobotModel(double r1, double B,double T1, RobotPose startPose);
    RobotPose getPose();
    double getTs();
    double getR();
    double getB();
    void setR(double a);
    void setB(double a);
    void setT(double T1);
    void iterate(Vector2d u);
    void setPose(Vector3d vektor);
};

#endif // ROBOTMODEL_H

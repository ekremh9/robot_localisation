#ifndef LOCALISATION_H
#define LOCALISATION_H

#include <Eigen/Dense>
#include <robotmodel.h>
#include <robotpose.h>

class Localisation //abstract class
{
protected:
    RobotModel robot;// = RobotModel(); nope
    double x = 0;
    double y = 0;
    double theta = 0;
public:
    Localisation();
    Localisation(RobotModel r);
    virtual RobotPose EstimatedPose() const = 0; //this makes it abstract
};


#endif // LOCALISATION_H
